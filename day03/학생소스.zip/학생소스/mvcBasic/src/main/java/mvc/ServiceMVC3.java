package mvc;

public class ServiceMVC3 {
	
	
	public String[] getFavorites() {
		//String[] result= { "one", "two","three"} ;
		String[] result= new String[3];
		result[0]="아메리카노";
		result[1]="떡볶이";
		result[2]="스시";		
		return result;
	}

}
