package mvc;

public class ServiceMVC2 {
	
	public String getMessage() {
		return "퐈이야";
	}

}
