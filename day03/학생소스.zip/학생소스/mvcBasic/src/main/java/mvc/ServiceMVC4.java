package mvc;

import java.util.ArrayList;

public class ServiceMVC4 {
	
	public ArrayList<String> getMovies(){
		
		ArrayList<String> list = new ArrayList<>();
		list.add( "쏘우");
		list.add( "엘리멘탈");
		list.add( "어벤져스");
		
		return list;
	}

}
